<script setup lang="ts">
// 사용법 페이지 — 정적 안내. 데이터 로직 없음.
// 각 단계는 steps 배열로 선언하고, 일부 단계(1·2·4)만 화면 예시(와이어프레임)를 곁들인다.
useHead({ title: '사용법' })

interface Step {
  no: number
  id: string
  title: string
  path: string
  to: string
  lead: string
  points: string[]
  tip?: string
}

const steps: Step[] = [
  {
    no: 1, id: 'family', title: '가족 설정', path: '사이드바 상단 · 가족 관리', to: '/family',
    lead: '가계부를 가족 구성원별로 따로 저장하고, 체크된 구성원만 합산해서 보여줍니다.',
    points: [
      '체크박스: 체크된 구성원의 데이터가 대시보드·수입/지출·카드 등에 합산됩니다.',
      '주(主) 멤버: 이름을 누르면 지정됩니다(주 배지). 엑셀 업로드와 신규 입력이 이 멤버에게 저장됩니다.',
      '사이드바의 가족 이름을 눌러 바로 수정할 수 있습니다 (Enter 저장 · Esc 취소).',
      '전체 링크: 모든 구성원을 한 번에 활성화합니다.'
    ],
    tip: '선택된 구성원이 0명이면 업로드가 비활성화됩니다.'
  },
  {
    no: 2, id: 'taxonomy', title: '카테고리 · 결제수단 설정', path: '설정', to: '/settings',
    lead: '모든 집계의 기준이 되는 분류표입니다. 한 번 정해두면 모든 메뉴에 똑같이 적용됩니다.',
    points: [
      '유형: 지출 / 수입 / 이체 / 저축 / 충전. 유형이 집계 위치를 결정합니다. 엑셀의 "타입" 열이 있으면 새 카테고리의 유형을 그 값으로 추정해 등록합니다(이체 + 저축·적금·투자 등의 이름은 저축). 틀리면 여기서 바꾸면 모든 거래가 바로 따라갑니다.',
      '고정비: 체크를 바꾸면 그 카테고리 거래의 구분(고정비/변동비)도 즉시 바뀝니다. 거래내역에서 카테고리를 바꿔도 구분이 새 카테고리에 맞춰집니다.',
      '지출제외: 지출은 지출 합계에서, 수입은 수입 합계에서 빠집니다. 저축은 켜도 저축 구성에 계속 집계됩니다. 이체는 원래 집계 대상이 아닙니다. 거래내역에는 남습니다.',
      '이름 변경·삭제: 대시보드 거래와 수입/지출 관리 항목에 함께 반영됩니다.',
      '활성화 스위치: 끄면 거래내역에서 숨겨집니다.',
      '가나다 정렬 버튼, ▲▼ 또는 드래그로 순서를 바꿉니다.',
      '결제수단은 소비/저축 태그를 지정할 수 있고, 태그별 카테고리 자동 배정에 쓰입니다.'
    ]
  },
  {
    no: 3, id: 'upload', title: '엑셀 업로드', path: '대시보드 · 업로드 카드', to: '/',
    lead: '가계부 엑셀을 올리면 브라우저 안에서 파싱·자동 분류합니다. 서버로 전송되지 않습니다.',
    points: [
      '필수 열: 날짜, 금액. 그 외 내용 · 카테고리 · 결제수단 · 구분(고정/변동) · 비고.',
      '헤더는 한/영 모두 인식합니다 (date, amount 등).',
      '뱅크샐러드 입출금 엑셀은 변환 없이 그대로 올리면 됩니다. "타입" 열이 지출인데 금액이 양수면 환불금으로 분류하고 원래 결제와 짝을 맞춥니다.',
      '카테고리·구분이 비어 있으면 내용(가맹점)과 설정된 규칙으로 자동 분류합니다.',
      '저장 대상은 사이드바의 주 멤버입니다. 샘플 데이터로 먼저 둘러볼 수도 있습니다.',
      '문제가 있으면 노란 "주의" 박스에 경고가 표시됩니다.'
    ]
  },
  {
    no: 4, id: 'transactions', title: '거래내역 확인 · 편집 · 저장', path: '대시보드 하단 거래내역 표', to: '/',
    lead: '이 앱의 핵심 작업 화면입니다. 업로드된 거래를 확인하고 분류를 바로잡습니다.',
    points: [
      '필터: 연도 · 월 · 카테고리 · 결제수단 · 고정/변동 · 검색어. 고급 필터로 금액/날짜 범위, 상태까지 좁힙니다.',
      '정렬: 열 머리글 클릭 (문자열은 가나다, 날짜·금액은 큰 값부터). 다시 누르면 방향이 바뀝니다.',
      '컬럼 버튼: 보일 열을 고릅니다 (내용·금액은 항상 표시).',
      '카테고리 변경: 해당 거래만(단건) 또는 같은 내용의 관련 거래 일괄 변경.',
      '배지: 수입 · 지출 · 이체 · 저축 · 환불 · 제외. 환불 배지는 카테고리가 "환불"인 거래에만 붙습니다. 상단 알약은 환불 건수·금액(환불 카테고리 기준)과 지출 계산 제외 건수를 보여줍니다.',
      '카테고리·구분·제외를 바꾸거나 삭제하면 KPI, 수입/지출/저축 구성, 흐름도, 카드, 수입/지출 관리의 가져온 항목에 모두 반영됩니다.',
      '삭제 모드: 삭제 버튼을 눌러야 선택 체크박스가 나타납니다.',
      '합계 푸터는 위 KPI와 항상 같은 값입니다.'
    ],
    tip: '편집은 메모리에만 있다가 [저장]을 눌러야 보관됩니다. 저장하지 않고 다른 메뉴로 이동하면 자동 저장되며 토스트로 알려줍니다. 화면에 "● 미저장 변경"이 보이면 아직 저장 전입니다.'
  },
  {
    no: 5, id: 'analysis', title: '분석 화면 읽기', path: '대시보드 중간 영역', to: '/',
    lead: '수입이 어디로 갔는지, 이번 달이 지난달·작년과 어떻게 다른지 보는 영역입니다.',
    points: [
      '순수지 카드 + 수입 배분 카드: 수입이 어디로 갔는지 한눈에 봅니다.',
      'KPI 카드: 총 수입 · 총 지출 · 월 저축 금액 · 고정비 · 변동비와 전월/전년 동월 대비 증감.',
      '수입지출 흐름(Sankey)과 수입·지출·저축 구성 막대: 수입 → 카테고리 → 지출/저축 흐름. 저축 구성에는 저축 유형 카테고리가 거래가 없어도 0원으로 표시됩니다.',
      '저축률 카드: 저축 ÷ 수입.',
      '사이드바 하단 "이번 달 요약": 총 수입 / 총 지출 / 순수익 (달이 바뀌면 자동 갱신).'
    ],
    tip: '지출에서 빠지는 것: 내 계좌 간 이체, 지출제외 카테고리, 환불 자동 제외 거래.'
  },
  {
    no: 6, id: 'income-expense', title: '수입/지출 관리', path: '수입/지출', to: '/income-expense',
    lead: '엑셀 없이 직접 입력하거나, 대시보드 사용내역을 월×카테고리 합계로 가져와 보는 화면입니다.',
    points: [
      '구분(수입/지출) 선택 → 금액 · 날짜 · 카테고리 입력 → 추가. 입력한 거래는 대시보드에도 자동 반영됩니다.',
      '사용내역 가져오기: 같은 (연월, 카테고리)는 중복 추가되지 않습니다. 재동기화와 가져온 항목 제거도 가능합니다.',
      '카테고리 합산표는 행을 펼치면 개별 건이 보입니다. 지출제외 카테고리는 "제외" 배지가 붙습니다.',
      '상단 합계: 총 수입 · 총 지출 · 순수익.'
    ]
  },
  {
    no: 7, id: 'spending-goals', title: '지출 목표 · 추이', path: '사이드바 "수입/지출" 바로 아래', to: '/spending-goals',
    lead: '월 목표 하나로 지출을 관리하고, 기간별 지출 추이를 목표선과 함께 봅니다.',
    points: [
      '월 목표를 입력하면 분기(×3) · 반기(×6) · 연(×12) 목표가 자동 계산됩니다. 필요한 기간만 직접 입력해 덮어쓸 수 있고 [저장]을 눌러야 보관됩니다.',
      '목표 대비 지출: 이번 달·분기·반기·올해의 지출, 달성률, 오늘 기준 페이스 눈금, 남은 기간 하루 사용 가능액.',
      '지출 추이: 일 / 주 / 월 / 분기 / 반기 / 년도 중 하나를 고릅니다. 일은 선택한 달의 누적 vs 페이스선, 주는 월 목표 환산 참고선, 나머지는 목표 점선과 초과 표시(빨강 + 글자)입니다. "표로 보기"로 같은 값을 표로 확인합니다.',
      '지출은 KPI와 같은 규칙으로 집계합니다(지출제외·환불 상계·이체·저축 제외). 가족 멤버 선택은 따르지만 대시보드의 기간·카테고리 필터는 적용되지 않습니다.'
    ],
    tip: '과거 기간의 초과 판정도 현재 목표를 기준으로 합니다. 목표를 바꾸면 지난 막대의 색도 달라집니다.'
  },
  {
    no: 8, id: 'assets', title: '자산 (현황 · 예적금 · 대출 · 카드)', path: '사이드바 "자산" 그룹', to: '/assets',
    lead: '자산과 부채, 카드 혜택을 따로 관리합니다.',
    points: [
      '자산 현황: 카테고리별 자산을 도넛과 타일로 보고 금액을 바로 수정합니다. 기준일을 정하고 "이번 달 스냅샷"으로 월별 변동 추이를 저장합니다.',
      '예금/적금: 적금 정보 입력 → 납입 입력. 가입일부터 월 납입 일괄 생성, 대시보드의 적금 거래를 납입 이력으로 가져오기(이미 가져온 건 건너뜀).',
      '대출: 대출 목록, 상환 비중 도넛, 연 이자, 1년 이내 만기 강조.',
      '카드: 대시보드 결제수단마다 카드를 자동 생성·연결(한 결제수단은 한 카드에만). 기간별 사용금액과 혜택 달성 현황.'
    ],
    tip: '지역화폐 같은 선불 자산은 카드와 연결해 쓰되 이중 집계되지 않도록 처리됩니다.'
  },
  {
    no: 9, id: 'schedule', title: '일정 (계약 · 기념일)', path: '사이드바 "일정" 그룹', to: '/contracts',
    lead: '날짜 기반으로 챙겨야 할 것들을 모아 둡니다.',
    points: [
      '계약 관리: 보험·통신·렌탈 등 계약을 등록하면 만료 D-day와 해지 통보 기한을 계산해 보여줍니다.',
      '기념일 관리: 생일·결혼기념일 등의 다음 발생일과 D-day를 자동 계산합니다. 곧 돌아오는 기념일은 상단 노란 박스에 표시됩니다.',
      '2/29 같은 윤일 기념일은 평년에 별도 규칙으로 처리됩니다.'
    ]
  }
]

const flowTop = [
  { t: '① 가족 설정', d: '사이드바 · 가족 관리' },
  { t: '② 분류 설정', d: '설정 · 카테고리/결제수단' },
  { t: '③ 엑셀 업로드', d: '대시보드 · 업로드 카드' }
]
const flowBottom = [
  { t: '⑤ 분석', d: 'KPI · 흐름 · 저축률' },
  { t: '⑥ 수입/지출 관리', d: '직접 입력 · 가져오기' },
  { t: '⑦ 지출 목표/추이', d: '목표 · 진행 · 추이 차트' },
  { t: '⑧ 자산', d: '예적금 · 대출 · 카드' },
  { t: '⑨ 일정', d: '계약 · 기념일' },
  { t: '⑩ 백업 (JSON)', d: '사이드바 하단 버튼', hot: true }
]

const rules = [
  ['내 통장 → 내 통장 이체', '이체 유형이라 수입·지출 어느 쪽에도 잡히지 않습니다.'],
  ['카테고리에 "지출제외" 체크', '지출·수입 합계에서 빠지고 거래내역에는 남습니다. 저축은 저축 구성에 계속 집계됩니다.'],
  ['환불로 짝이 맞은 같은 내용 거래', '자동으로 지출 제외 체크 + 배지. 환불 카테고리 금액에는 취소선이 붙습니다.'],
  ['음수 금액 거래', '수입지출 흐름(Sankey) 집계에 반영됩니다.'],
  ['카테고리 이름 · 유형 · 순서 변경', '모든 메뉴에 동일하게 반영됩니다.'],
  ['거래내역 카테고리 변경 · 삭제', '구분(고정/변동)과 수입·지출·저축 구성, 흐름도, 카드, 수입/지출 관리 가져온 항목이 함께 갱신됩니다.'],
  ['저장하지 않고 다른 메뉴로 이동', '자동 저장되고 토스트로 알려줍니다.']
]
</script>

<template>
  <div class="page-shell section-gap">
    <!-- 헤더 -->
    <div>
      <h2 class="text-2xl font-bold text-slate-900">사용법</h2>
      <p class="text-sm text-slate-500 mt-0.5">처음이라면 위에서부터 순서대로 따라가세요. 모든 데이터는 이 브라우저 안에서만 처리됩니다.</p>
    </div>

    <!-- 가장 중요한 것 -->
    <section class="rounded-2xl border-2 border-emerald-500 bg-emerald-50 p-4 sm:p-5">
      <div class="flex items-start gap-3">
        <div class="w-10 h-10 flex-shrink-0 rounded-xl bg-emerald-600 text-white grid place-items-center">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        </div>
        <div class="text-sm text-emerald-900 leading-relaxed">
          <div class="font-bold text-base">★ 가장 중요한 두 가지</div>
          <p class="mt-1">
            ① 사이드바 하단의 녹색 <b>[전체 데이터 백업]</b> 버튼 &nbsp;②
            내려받은 <b class="px-1.5 py-0.5 rounded bg-emerald-600 text-white">백업 JSON 파일</b> 보관.
          </p>
          <p class="mt-1">서버에는 아무것도 저장되지 않아서, 내 데이터의 유일한 사본은 브라우저 저장소와 백업 JSON 파일입니다. <a href="#backup" class="underline font-semibold">자세히 보기</a></p>
        </div>
      </div>
    </section>

    <!-- 전체 흐름도 -->
    <section class="card">
      <h3 class="font-semibold text-slate-900">전체 사용 흐름</h3>
      <!-- 겹침 방지: 고정 좌표 SVG 대신 flex/grid. 좁은 화면에서는 세로로 쌓인다 -->
      <div class="mt-3 flex flex-col items-stretch gap-2">
        <div class="flex flex-col md:flex-row md:items-stretch gap-2">
          <template v-for="(f, i) in flowTop" :key="f.t">
            <div class="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-2.5">
              <div class="text-sm font-bold text-slate-900">{{ f.t }}</div>
              <div class="text-xs text-slate-500 mt-0.5">{{ f.d }}</div>
            </div>
            <div v-if="i < flowTop.length - 1" class="flow-arrow">→</div>
          </template>
        </div>
        <div class="flow-down">↓</div>
        <div class="rounded-xl border-2 border-brand-600 bg-brand-50 px-4 py-3 text-center">
          <div class="text-sm font-bold text-brand-700">④ 거래내역 확인 · 편집</div>
          <div class="text-xs text-slate-600 mt-0.5">필터 · 카테고리 변경 · 환불 · <b>[저장]</b></div>
        </div>
        <div class="flow-down">↓</div>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
          <div v-for="f in flowBottom" :key="f.t"
               :class="['rounded-xl px-3 py-2.5 border', f.hot ? 'border-2 border-emerald-500 bg-emerald-50' : 'border-slate-200 bg-white']">
            <div :class="['text-sm font-bold', f.hot ? 'text-emerald-700' : 'text-slate-900']">{{ f.t }}</div>
            <div class="text-xs text-slate-500 mt-0.5">{{ f.d }}</div>
          </div>
        </div>
      </div>
      <p class="text-xs text-slate-400 mt-1">②와 ③은 순서가 바뀌어도 되지만, 먼저 분류를 설정하면 업로드 직후 자동 분류가 더 정확합니다.</p>
    </section>

    <!-- 단계 카드 -->
    <section v-for="s in steps" :id="s.id" :key="s.id" class="card">
      <div class="grid lg:grid-cols-2 gap-5 items-start">
        <div>
          <div class="flex items-center gap-2">
            <span class="w-7 h-7 rounded-full bg-brand-600 text-white grid place-items-center text-sm font-bold flex-shrink-0">{{ s.no }}</span>
            <h3 class="font-semibold text-slate-900 text-lg">{{ s.title }}</h3>
          </div>
          <div class="text-xs text-slate-400 mt-1">{{ s.path }}</div>
          <p class="text-sm text-slate-700 mt-2">{{ s.lead }}</p>
          <ul class="mt-2 space-y-1 text-sm text-slate-600 list-disc list-inside">
            <li v-for="p in s.points" :key="p">{{ p }}</li>
          </ul>
          <div v-if="s.tip" class="mt-3 rounded-lg bg-amber-50 border border-amber-200 px-3 py-2 text-[13px] text-amber-900">💡 {{ s.tip }}</div>
          <NuxtLink :to="s.to" class="inline-flex items-center gap-1 mt-3 text-sm font-semibold text-brand-600 hover:text-brand-700">바로가기 →</NuxtLink>
        </div>

        <!-- 화면 예시 -->
        <div class="rounded-xl border border-slate-200 bg-slate-50 p-3 text-[11.5px] text-slate-500 overflow-x-auto min-w-0">
          <template v-if="s.id === 'family'">
            <div class="flex justify-between mb-2"><b class="text-slate-800">FAMILY · 견우와 직녀 ✎</b><span>전체 · 관리</span></div>
            <div class="rounded-md border border-slate-200 bg-white px-2 py-1.5 mb-1 text-slate-800">☑ 😀 견우 <span class="ml-1 px-1.5 rounded bg-brand-600 text-white text-[9px] font-bold">주</span></div>
            <div class="rounded-md border border-slate-200 bg-white px-2 py-1.5 mb-1 text-slate-800">☑ 😊 직녀 <span class="float-right">배우자</span></div>
            <div class="rounded-md border border-dashed border-slate-300 px-2 py-1.5 text-center">+ 가족 추가</div>
            <p class="mt-2">체크 = 합산 포함 · 이름 클릭 = 주 멤버 지정</p>
          </template>
          <template v-else-if="s.id === 'taxonomy'">
            <table class="w-full bg-white border border-slate-200 rounded-md overflow-hidden">
              <thead class="bg-slate-50"><tr><th class="text-left p-1.5">카테고리</th><th class="text-left p-1.5">유형</th><th class="p-1.5">고정비</th><th class="p-1.5">지출제외</th></tr></thead>
              <tbody class="text-slate-800">
                <tr class="border-t"><td class="p-1.5">식비</td><td class="p-1.5">지출</td><td class="text-center">☐</td><td class="text-center">☐</td></tr>
                <tr class="border-t"><td class="p-1.5">관리비</td><td class="p-1.5">지출</td><td class="text-center">☑</td><td class="text-center">☐</td></tr>
                <tr class="border-t"><td class="p-1.5">급여</td><td class="p-1.5">수입</td><td class="text-center">–</td><td class="text-center">–</td></tr>
                <tr class="border-t"><td class="p-1.5">내 계좌이체</td><td class="p-1.5">이체</td><td class="text-center">–</td><td class="text-center">–</td></tr>
                <tr class="border-t"><td class="p-1.5">환불</td><td class="p-1.5">지출</td><td class="text-center">☐</td><td class="text-center">☑</td></tr>
              </tbody>
            </table>
            <p class="mt-2">지출 카테고리만 고정비 / 지출제외를 지정할 수 있습니다.</p>
          </template>
          <template v-else-if="s.id === 'transactions'">
            <div class="flex justify-between items-center mb-2">
              <b class="text-rose-600">● 미저장 변경</b>
              <span class="px-2.5 py-1 rounded-md bg-brand-600 text-white font-semibold">저장</span>
            </div>
            <table class="w-full bg-white border border-slate-200 rounded-md overflow-hidden text-slate-800">
              <thead class="bg-slate-50 text-slate-500"><tr><th class="text-left p-1.5">날짜</th><th class="text-left p-1.5">내용</th><th class="text-left p-1.5">카테고리</th><th class="text-right p-1.5">금액</th></tr></thead>
              <tbody>
                <tr class="border-t"><td class="p-1.5">10-03</td><td class="p-1.5">이마트</td><td class="p-1.5">마트 ▾</td><td class="p-1.5 text-right text-rose-600">-52,300</td></tr>
                <tr class="border-t"><td class="p-1.5">10-02</td><td class="p-1.5">쿠팡</td><td class="p-1.5">쇼핑 ▾</td><td class="p-1.5 text-right text-rose-600">-18,900</td></tr>
                <tr class="border-t"><td class="p-1.5">10-02</td><td class="p-1.5">쿠팡 <span class="text-amber-600 border border-amber-400 rounded px-1 text-[9px]">환불</span></td><td class="p-1.5">환불 ▾</td><td class="p-1.5 text-right text-blue-600 line-through">+18,900</td></tr>
              </tbody>
            </table>
            <p class="mt-2">카테고리 셀을 누르면 단건 / 관련 거래 일괄 변경을 고를 수 있습니다.</p>
          </template>
          <template v-else>
            <div class="text-center py-6 text-slate-400">
              <div class="text-2xl">{{ s.no }}</div>
              <div class="mt-1">{{ s.title }}</div>
              <NuxtLink :to="s.to" class="mt-2 inline-block text-brand-600 font-semibold">화면 열기 →</NuxtLink>
            </div>
          </template>
        </div>
      </div>
    </section>

    <!-- 9. 백업 (강조) -->
    <section id="backup" class="rounded-2xl border-2 border-emerald-500 bg-white p-4 sm:p-6 shadow-[0_0_0_4px_rgba(5,150,105,0.12)]">
      <div class="flex items-center gap-2">
        <span class="w-7 h-7 rounded-full bg-emerald-600 text-white grid place-items-center text-sm font-bold flex-shrink-0">9</span>
        <h3 class="font-bold text-slate-900 text-xl">백업 <span class="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-base">JSON 파일</span> — 가장 중요 ★</h3>
      </div>
      <div class="mt-3 rounded-lg bg-emerald-600 text-white font-bold px-4 py-3">
        📦 내 데이터의 유일한 사본은 "백업 JSON 파일"입니다. 서버에는 아무것도 저장되지 않습니다.
      </div>

      <!-- 박스 3개 + 화살표 라벨은 박스 사이 별도 칸에 둔다 (겹침 없음). 좁은 화면에서는 세로 배치 -->
      <div class="mt-4 grid grid-cols-1 md:grid-cols-[1fr_auto_1fr_auto_1.2fr] items-stretch gap-2">
        <div class="rounded-xl border border-slate-200 bg-white p-3">
          <div class="text-sm font-bold text-slate-900">화면 (메모리)</div>
          <div class="text-xs text-slate-500 mt-1">편집 중인 거래</div>
          <div class="text-xs text-rose-600 mt-0.5">● 미저장 변경</div>
        </div>
        <div class="flow-link"><span class="flow-arrow">→</span><span class="flow-label">[저장] 또는<br class="hidden md:inline" /> 메뉴 이동</span></div>
        <div class="rounded-xl border border-slate-200 bg-white p-3">
          <div class="text-sm font-bold text-slate-900">브라우저 저장소</div>
          <div class="text-xs text-slate-500 mt-1">이 PC · 이 브라우저에만 존재</div>
          <div class="text-xs text-slate-500 mt-0.5">가족별 독립 저장</div>
        </div>
        <div class="flow-link"><span class="flow-arrow text-emerald-600">→</span><span class="flow-label text-emerald-700 font-semibold">전체 데이터<br class="hidden md:inline" /> 백업</span></div>
        <div class="rounded-xl border-[3px] border-emerald-600 bg-emerald-50 p-3">
          <div class="text-base font-bold text-emerald-700">★ 백업 JSON 파일</div>
          <div class="text-xs text-slate-600 mt-1 break-all">expense-backup-날짜.json</div>
          <div class="text-xs text-slate-600 mt-0.5">PC · 클라우드 · USB 2곳 이상 보관</div>
        </div>
      </div>
      <div class="mt-2 rounded-lg border border-dashed border-emerald-500 px-3 py-2 text-xs text-emerald-800">
        ↩ 복원: <b>설정 › 백업·복원 › 가져오기</b> 로 JSON을 다시 불러오면 브라우저 저장소가 복구됩니다.
      </div>

      <div class="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3 flex flex-wrap items-center gap-3 text-sm text-slate-600">
        <b class="text-slate-800">사이드바 하단 · 모든 페이지 공통</b>
        <span class="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-semibold">⬇ 전체 데이터 백업</span>
        <span>→ 저장 후 <b class="px-1 rounded bg-emerald-600 text-white">JSON</b> 다운로드 → "저장·백업 완료" 표시</span>
      </div>

      <ul class="mt-3 text-sm text-slate-700 divide-y divide-dashed divide-slate-200">
        <li class="py-1.5">✅ <b>언제</b> — 엑셀 업로드 직후, 대량 편집 후, 최소 월 1회</li>
        <li class="py-1.5">✅ <b>어디에</b> — 다운로드된 JSON을 PC 외 클라우드/USB에도 복사</li>
        <li class="py-1.5">✅ <b>복원</b> — 설정 › 백업·복원에서 JSON 선택 → 덮어쓰기 등 전략 선택, 완료 후 자동 새로고침</li>
        <li class="py-1.5">✅ <b>자동 저장</b> — 다른 메뉴로 이동하면 미저장 변경이 저장됩니다. 변경이 없으면 저장소를 다시 쓰지 않습니다.</li>
        <li class="py-1.5 text-rose-700">⛔ 브라우저 사이트 데이터 삭제 · 시크릿 모드 · PC 교체 시 JSON이 없으면 복구할 수 없습니다.</li>
      </ul>
      <NuxtLink to="/settings" class="inline-flex items-center gap-1 mt-3 text-sm font-semibold text-emerald-700 hover:text-emerald-800">설정 › 백업·복원 바로가기 →</NuxtLink>
    </section>

    <!-- 규칙 표 -->
    <section class="card">
      <h3 class="font-semibold text-slate-900">자주 헷갈리는 규칙</h3>
      <div class="overflow-x-auto"><table class="w-full mt-2 text-sm min-w-[420px]">
        <thead><tr class="text-left text-xs text-slate-500"><th class="py-1.5 pr-3 font-semibold">상황</th><th class="py-1.5 font-semibold">이렇게 처리됩니다</th></tr></thead>
        <tbody>
          <tr v-for="r in rules" :key="r[0]" class="border-t border-slate-100 align-top">
            <td class="py-2 pr-3 text-slate-800 font-medium">{{ r[0] }}</td>
            <td class="py-2 text-slate-600">{{ r[1] }}</td>
          </tr>
        </tbody>
      </table></div>
    </section>
  </div>
</template>

<style scoped>
/* 흐름 화살표: 데스크톱은 가로(→), 모바일은 세로 배치라 ↓ 방향으로 돌린다 */
.flow-arrow,
.flow-down {
  display: grid;
  place-items: center;
  font-size: 18px;
  font-weight: 700;
  color: #94a3b8;
  line-height: 1;
}
.flow-link {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  padding: 2px 4px;
  text-align: center;
}
.flow-label { font-size: 11px; line-height: 1.3; color: #64748b; white-space: nowrap; }
/* 모바일(세로 배치)에서는 → 를 ↓ 로 보이게 회전 */
@media (max-width: 767px) {
  .flow-arrow, .flow-link .flow-arrow { transform: rotate(90deg); }
  .flow-label { white-space: normal; }
  .flow-link { flex-direction: row; gap: 8px; justify-content: center; }
}
</style>
